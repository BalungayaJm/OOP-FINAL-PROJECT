using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Views
{
    public partial class BooksView : UserControl
    {
        private Book? _selectedBook;
        private bool _isLoaded;

        public BooksView()
        {
            InitializeComponent();
            Loaded += BooksView_Loaded;
            AppEvents.DataChanged += OnDataChanged;
        }

        private void BooksView_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isLoaded) return;
            _isLoaded = true;
            LoadBooks();
        }

        private void OnDataChanged()
        {
            if (!_isLoaded) return;
            LoadBooks(SearchBox.Text);
        }

        private void LoadBooks(string? searchTerm = null)
        {
            BooksGrid.ItemsSource = DatabaseHelper.GetAllBooks(searchTerm);
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => LoadBooks(SearchBox.Text);
        private void Search_Click(object sender, RoutedEventArgs e) => LoadBooks(SearchBox.Text);

        private void BooksGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedBook = BooksGrid.SelectedItem as Book;
            if (_selectedBook != null)
            {
                FormTitle.Text = "Edit Book";
                TitleBox.Text = _selectedBook.Title;
                AuthorBox.Text = _selectedBook.Author;
                IsbnBox.Text = _selectedBook.ISBN;
                GenreBox.Text = _selectedBook.Genre;
                TotalCopiesBox.Text = _selectedBook.TotalCopies.ToString();
                DeleteButton.IsEnabled = true;
                SaveButton.Content = "Update Book";
            }
            HideError();
        }

        private void Clear_Click(object sender, RoutedEventArgs e) => ClearForm();

        private void ClearForm()
        {
            _selectedBook = null;
            BooksGrid.SelectedItem = null;
            FormTitle.Text = "Add a Book";
            TitleBox.Text = AuthorBox.Text = IsbnBox.Text = GenreBox.Text = TotalCopiesBox.Text = "";
            DeleteButton.IsEnabled = false;
            SaveButton.Content = "Save Book";
            HideError();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var title = TitleBox.Text.Trim();
            var author = AuthorBox.Text.Trim();
            var isbn = IsbnBox.Text.Trim();
            var genre = GenreBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author) || string.IsNullOrWhiteSpace(isbn))
            {
                ShowError("Title, Author, and ISBN are required.");
                return;
            }

            if (!IsValidIsbn(isbn))
            {
                ShowError("ISBN must be a valid 10- or 13-digit ISBN (dashes are fine).");
                return;
            }

            if (!int.TryParse(TotalCopiesBox.Text.Trim(), out var totalCopies) || totalCopies < 1)
            {
                ShowError("Total Copies must be a whole number of 1 or more.");
                return;
            }

            try
            {
                if (_selectedBook == null)
                {
                    DatabaseHelper.AddBook(new Book
                    {
                        Title = title,
                        Author = author,
                        ISBN = isbn,
                        Genre = genre,
                        TotalCopies = totalCopies,
                        AvailableCopies = totalCopies
                    });
                    DatabaseHelper.LogTransaction(Session.StaffName, "Added Book", $"Added \"{title}\" by {author}");
                }
                else
                {
                    var loanedOut = _selectedBook.TotalCopies - _selectedBook.AvailableCopies;
                    if (totalCopies < loanedOut)
                    {
                        ShowError($"Total Copies can't be less than the {loanedOut} currently on loan.");
                        return;
                    }

                    _selectedBook.Title = title;
                    _selectedBook.Author = author;
                    _selectedBook.ISBN = isbn;
                    _selectedBook.Genre = genre;
                    _selectedBook.AvailableCopies = totalCopies - loanedOut;
                    _selectedBook.TotalCopies = totalCopies;
                    DatabaseHelper.UpdateBook(_selectedBook);
                    DatabaseHelper.LogTransaction(Session.StaffName, "Updated Book", $"Updated \"{title}\" by {author}");
                }

                LoadBooks(SearchBox.Text);
                ClearForm();
            }
            catch (Microsoft.Data.Sqlite.SqliteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                ShowError("A book with this ISBN already exists.");
            }
            catch (Exception ex)
            {
                ShowError($"Could not save the book: {ex.Message}");
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedBook == null) return;

            var confirmWindow = new ConfirmCredentialsWindow(
                $"Enter your staff email and password to permanently delete \"{_selectedBook.Title}\".")
            { Owner = Window.GetWindow(this) };

            if (confirmWindow.ShowDialog() != true) return;

            try
            {
                DatabaseHelper.DeleteBook(_selectedBook.Id);
                DatabaseHelper.LogTransaction(confirmWindow.ConfirmedByStaffName, "Deleted Book",
                    $"Deleted \"{_selectedBook.Title}\" by {_selectedBook.Author}");
                LoadBooks(SearchBox.Text);
                ClearForm();
            }
            catch (InvalidOperationException ex)
            {
                ShowError(ex.Message);
            }
            catch (Exception ex)
            {
                ShowError($"Could not delete the book: {ex.Message}");
            }
        }

        private static bool IsValidIsbn(string isbn)
        {
            var cleaned = isbn.Replace("-", "").Replace(" ", "");
            if (cleaned.Length == 10) return Regex.IsMatch(cleaned, @"^\d{9}[\dXx]$");
            if (cleaned.Length == 13) return Regex.IsMatch(cleaned, @"^\d{13}$");
            return false;
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorText.Visibility = Visibility.Visible;
        }

        private void HideError() => ErrorText.Visibility = Visibility.Collapsed;
    }
}
