using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem.Views
{
    public partial class HistoryView : UserControl
    {
        private bool _isLoaded;

        public HistoryView()
        {
            InitializeComponent();
            Loaded += HistoryView_Loaded;
            AppEvents.DataChanged += OnDataChanged;
        }

        private void HistoryView_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isLoaded) return;
            _isLoaded = true;
            LoadHistory();
        }

        private void OnDataChanged()
        {
            if (!_isLoaded) return;
            LoadHistory();
        }

        private void LoadHistory()
        {
            var term = SearchBox.Text?.Trim();
            var all = DatabaseHelper.GetAllTransactions();

            if (!string.IsNullOrWhiteSpace(term))
            {
                all = all.Where(t =>
                    t.StaffName.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                    t.ActionType.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                    t.Details.Contains(term, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            HistoryGrid.ItemsSource = all;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => LoadHistory();
        private void Search_Click(object sender, RoutedEventArgs e) => LoadHistory();
    }
}
