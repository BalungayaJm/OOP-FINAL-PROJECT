using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Views
{
    public partial class LoansView : UserControl
    {
        private bool _isLoaded;

        public LoansView()
        {
            InitializeComponent();
            Loaded += LoansView_Loaded;
            AppEvents.DataChanged += OnDataChanged;
        }

        private void LoansView_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isLoaded) return;
            _isLoaded = true;
            LoadLoans();
            LoadComboBoxes();
        }

        private void OnDataChanged()
        {
            if (!_isLoaded) return;
            LoadLoans();
            LoadComboBoxes();
        }

        private void LoadLoans()
        {
            var term = SearchBox.Text?.Trim();
            var allLoans = DatabaseHelper.GetAllLoans();

            if (!string.IsNullOrWhiteSpace(term))
            {
                allLoans = allLoans.Where(l =>
                    l.BookTitle.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                    l.MemberName.Contains(term, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            ActiveLoansGrid.ItemsSource = allLoans.Where(l => !l.IsReturned).ToList();
            ReturnedLoansGrid.ItemsSource = allLoans.Where(l => l.IsReturned).ToList();
        }

        private void LoadComboBoxes()
        {
            BookCombo.ItemsSource = DatabaseHelper.GetAllBooks().Where(b => b.AvailableCopies > 0).ToList();
            MemberCombo.ItemsSource = DatabaseHelper.GetAllMembers();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => LoadLoans();
        private void Search_Click(object sender, RoutedEventArgs e) => LoadLoans();

        private void Checkout_Click(object sender, RoutedEventArgs e)
        {
            var book = BookCombo.SelectedItem as Book;
            var member = MemberCombo.SelectedItem as Member;

            if (book == null || member == null)
            {
                ShowError("Select both a book and a member before checking out.");
                return;
            }

            try
            {
                DatabaseHelper.CheckoutBook(book.Id, member.Id);
                DatabaseHelper.LogTransaction(Session.StaffName, "Checked Out",
                    $"\"{book.Title}\" checked out to {member.FullName}");
                LoadLoans();
                LoadComboBoxes();
                HideError();
            }
            catch (InvalidOperationException ex)
            {
                ShowError(ex.Message);
            }
            catch (Exception ex)
            {
                ShowError($"Could not check out the book: {ex.Message}");
            }
        }

        private void ActiveLoansGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (FindAncestor<DataGridRow>(e.OriginalSource as DependencyObject) == null) return;

            var loan = ActiveLoansGrid.SelectedItem as Loan;
            if (loan == null) return;

            var confirm = MessageBox.Show(
                $"Has \"{loan.BookTitle}\" been returned by {loan.MemberName}?",
                "Confirm Return",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (confirm != MessageBoxResult.Yes) return;

            try
            {
                DatabaseHelper.ReturnBook(loan.Id);
                DatabaseHelper.LogTransaction(Session.StaffName, "Approved Return",
                    $"\"{loan.BookTitle}\" marked returned by {loan.MemberName}");
                LoadLoans();
                LoadComboBoxes();
                HideError();
            }
            catch (InvalidOperationException ex)
            {
                ShowError(ex.Message);
            }
            catch (Exception ex)
            {
                ShowError($"Could not return the book: {ex.Message}");
            }
        }

        private void DeleteActiveLoan_Click(object sender, RoutedEventArgs e) =>
            DeleteLoan(ActiveLoansGrid.SelectedItem as Loan);

        private void DeleteReturnedLoan_Click(object sender, RoutedEventArgs e) =>
            DeleteLoan(ReturnedLoansGrid.SelectedItem as Loan);

        private void DeleteLoan(Loan? loan)
        {
            if (loan == null)
            {
                ShowError("Select a loan record in the list first.");
                return;
            }

            var confirmWindow = new ConfirmCredentialsWindow(
                $"Enter your staff email and password to permanently delete this loan record for \"{loan.BookTitle}\".")
            { Owner = Window.GetWindow(this) };

            if (confirmWindow.ShowDialog() != true) return;

            try
            {
                DatabaseHelper.DeleteLoan(loan.Id);
                DatabaseHelper.LogTransaction(confirmWindow.ConfirmedByStaffName, "Deleted Loan",
                    $"Deleted loan record for \"{loan.BookTitle}\" ({loan.MemberName})");
                LoadLoans();
                LoadComboBoxes();
                HideError();
            }
            catch (Exception ex)
            {
                ShowError($"Could not delete the loan record: {ex.Message}");
            }
        }

        private static T? FindAncestor<T>(DependencyObject? current) where T : DependencyObject
        {
            while (current != null)
            {
                if (current is T match) return match;
                current = VisualTreeHelper.GetParent(current);
            }
            return null;
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorText.Visibility = Visibility.Visible;
        }

        private void HideError() => ErrorText.Visibility = Visibility.Collapsed;
    }
}
