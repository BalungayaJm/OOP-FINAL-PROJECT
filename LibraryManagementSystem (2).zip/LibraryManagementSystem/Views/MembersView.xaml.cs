using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Views
{
    public partial class MembersView : UserControl
    {
        private Member? _selectedMember;
        private bool _isLoaded;
        private static readonly Regex EmailPattern = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");

        public MembersView()
        {
            InitializeComponent();
            Loaded += MembersView_Loaded;
            AppEvents.DataChanged += OnDataChanged;
        }

        private void MembersView_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isLoaded) return;
            _isLoaded = true;
            LoadMembers();
        }

        private void OnDataChanged()
        {
            if (!_isLoaded) return;
            LoadMembers(SearchBox.Text);
        }

        private void LoadMembers(string? searchTerm = null)
        {
            MembersGrid.ItemsSource = DatabaseHelper.GetAllMembers(searchTerm);
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => LoadMembers(SearchBox.Text);
        private void Search_Click(object sender, RoutedEventArgs e) => LoadMembers(SearchBox.Text);

        private void MembersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedMember = MembersGrid.SelectedItem as Member;
            if (_selectedMember != null)
            {
                FormTitle.Text = "Edit Member";
                NameBox.Text = _selectedMember.FullName;
                EmailBox.Text = _selectedMember.Email;
                PhoneBox.Text = _selectedMember.Phone;
                DeleteButton.IsEnabled = true;
                SaveButton.Content = "Update Member";
            }
            HideError();
        }

        private void Clear_Click(object sender, RoutedEventArgs e) => ClearForm();

        private void ClearForm()
        {
            _selectedMember = null;
            MembersGrid.SelectedItem = null;
            FormTitle.Text = "Add a Member";
            NameBox.Text = EmailBox.Text = PhoneBox.Text = "";
            DeleteButton.IsEnabled = false;
            SaveButton.Content = "Save Member";
            HideError();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var name = NameBox.Text.Trim();
            var email = EmailBox.Text.Trim();
            var phone = PhoneBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email))
            {
                ShowError("Full Name and Email are required.");
                return;
            }

            if (!EmailPattern.IsMatch(email))
            {
                ShowError("Enter a valid email address.");
                return;
            }

            try
            {
                if (_selectedMember == null)
                {
                    DatabaseHelper.AddMember(new Member
                    {
                        FullName = name,
                        Email = email,
                        Phone = phone,
                        JoinDate = DateTime.Now
                    });
                    DatabaseHelper.LogTransaction(Session.StaffName, "Added Member", $"Added member {name} ({email})");
                }
                else
                {
                    _selectedMember.FullName = name;
                    _selectedMember.Email = email;
                    _selectedMember.Phone = phone;
                    DatabaseHelper.UpdateMember(_selectedMember);
                    DatabaseHelper.LogTransaction(Session.StaffName, "Updated Member", $"Updated member {name} ({email})");
                }

                LoadMembers(SearchBox.Text);
                ClearForm();
            }
            catch (Microsoft.Data.Sqlite.SqliteException ex) when (ex.Message.Contains("UNIQUE"))
            {
                ShowError("A member with this email already exists.");
            }
            catch (Exception ex)
            {
                ShowError($"Could not save the member: {ex.Message}");
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedMember == null) return;

            var confirmWindow = new ConfirmCredentialsWindow(
                $"Enter your staff email and password to permanently delete \"{_selectedMember.FullName}\".")
            { Owner = Window.GetWindow(this) };

            if (confirmWindow.ShowDialog() != true) return;

            try
            {
                DatabaseHelper.DeleteMember(_selectedMember.Id);
                DatabaseHelper.LogTransaction(confirmWindow.ConfirmedByStaffName, "Deleted Member",
                    $"Deleted member {_selectedMember.FullName} ({_selectedMember.Email})");
                LoadMembers(SearchBox.Text);
                ClearForm();
            }
            catch (InvalidOperationException ex)
            {
                ShowError(ex.Message);
            }
            catch (Exception ex)
            {
                ShowError($"Could not delete the member: {ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorText.Visibility = Visibility.Visible;
        }

        private void HideError() => ErrorText.Visibility = Visibility.Collapsed;
    }
}
