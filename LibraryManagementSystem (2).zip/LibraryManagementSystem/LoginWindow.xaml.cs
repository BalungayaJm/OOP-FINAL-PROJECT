using System.Windows;
using System.Windows.Input;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var email = EmailBox.Text.Trim();
            var password = PasswordBox.Password;

            var staff = StaffAccounts.Validate(email, password);
            if (staff == null)
            {
                ErrorText.Text = "Incorrect email or password.";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            Session.StaffName = staff.Value.Name;
            Session.StaffEmail = staff.Value.Email;
            DialogResult = true;
        }

        private void Input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) Login_Click(sender, e);
        }
    }
}
