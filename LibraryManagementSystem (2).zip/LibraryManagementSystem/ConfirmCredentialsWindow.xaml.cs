using System.Windows;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem
{
    public partial class ConfirmCredentialsWindow : Window
    {
        public string ConfirmedByStaffName { get; private set; } = "";

        public ConfirmCredentialsWindow(string message)
        {
            InitializeComponent();
            MessageText.Text = message;
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            var email = EmailBox.Text.Trim();
            var password = PasswordBox.Password;

            var staff = StaffAccounts.Validate(email, password);
            if (staff == null)
            {
                ErrorText.Text = "Incorrect email or password. Deletion was not confirmed.";
                ErrorText.Visibility = Visibility.Visible;
                return;
            }

            ConfirmedByStaffName = staff.Value.Name;
            DialogResult = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
