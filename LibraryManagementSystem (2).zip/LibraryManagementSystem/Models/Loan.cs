using System;

namespace LibraryManagementSystem.Models
{
    public class Loan
    {
        public int Id { get; set; }
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public int MemberId { get; set; }
        public string MemberName { get; set; } = string.Empty;
        public DateTime LoanDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public bool IsReturned { get; set; }

        public string LoanDateLabel => LoanDate.ToString("MMM d, yyyy");
        public string DueDateLabel => DueDate.ToString("MMM d, yyyy");
        public string ReturnDateLabel => ReturnDate.HasValue ? ReturnDate.Value.ToString("MMM d, yyyy") : "";

        public string StatusLabel
        {
            get
            {
                if (IsReturned) return "Returned";
                return DateTime.Now.Date > DueDate.Date ? "Overdue" : "On Loan";
            }
        }
    }
}
