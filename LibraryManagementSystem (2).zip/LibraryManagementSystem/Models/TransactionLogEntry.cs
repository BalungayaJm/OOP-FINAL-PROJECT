using System;

namespace LibraryManagementSystem.Models
{
    public class TransactionLogEntry
    {
        public int Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string StaffName { get; set; } = string.Empty;
        public string ActionType { get; set; } = string.Empty;
        public string Details { get; set; } = string.Empty;

        public string TimestampLabel => Timestamp.ToString("MMM d, yyyy h:mm tt");
    }
}
