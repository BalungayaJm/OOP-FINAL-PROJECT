using System;

namespace LibraryManagementSystem.Models
{
    public class Member
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public DateTime JoinDate { get; set; }
        public string JoinDateLabel => JoinDate.ToString("MMM d, yyyy");
    }
}
