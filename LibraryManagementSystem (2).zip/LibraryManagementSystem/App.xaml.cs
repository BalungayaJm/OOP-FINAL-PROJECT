using System;
using System.Windows;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Without this, WPF's default behavior closes the whole app the moment
            // LoginWindow closes, since at that instant it's the only open window -
            // even though we're about to open MainWindow right after.
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            try
            {
                DatabaseHelper.Initialize();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"The application could not set up its database and will now close.\n\nDetails: {ex.Message}",
                    "Startup Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown();
                return;
            }

            var login = new LoginWindow();
            var loggedIn = login.ShowDialog();

            if (loggedIn == true)
            {
                var main = new MainWindow();
                Current.MainWindow = main;
                ShutdownMode = ShutdownMode.OnMainWindowClose;
                main.Show();
            }
            else
            {
                Shutdown();
            }
        }
    }
}
