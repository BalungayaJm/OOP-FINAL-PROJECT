using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    /// <summary>
    /// All database access for the app. Each method opens its own short-lived
    /// connection, which keeps things simple and safe for a single-user desktop app.
    /// </summary>
    public static class DatabaseHelper
    {
        private static readonly string DbPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "library.db");

        private static readonly string ConnectionString = $"Data Source={DbPath}";

        public static void Initialize()
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var createTables = @"
                CREATE TABLE IF NOT EXISTS Books (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Title TEXT NOT NULL,
                    Author TEXT NOT NULL,
                    ISBN TEXT NOT NULL UNIQUE,
                    Genre TEXT,
                    TotalCopies INTEGER NOT NULL,
                    AvailableCopies INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Members (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    FullName TEXT NOT NULL,
                    Email TEXT NOT NULL UNIQUE,
                    Phone TEXT,
                    JoinDate TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS Loans (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    BookId INTEGER NOT NULL,
                    MemberId INTEGER NOT NULL,
                    LoanDate TEXT NOT NULL,
                    DueDate TEXT NOT NULL,
                    ReturnDate TEXT,
                    IsReturned INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY (BookId) REFERENCES Books(Id),
                    FOREIGN KEY (MemberId) REFERENCES Members(Id)
                );

                CREATE TABLE IF NOT EXISTS TransactionHistory (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Timestamp TEXT NOT NULL,
                    StaffName TEXT NOT NULL,
                    ActionType TEXT NOT NULL,
                    Details TEXT NOT NULL
                );";

            using var command = new SqliteCommand(createTables, connection);
            command.ExecuteNonQuery();
        }

        // ---------------------------------------------------------------- Books

        public static List<Book> GetAllBooks(string? searchTerm = null)
        {
            var books = new List<Book>();
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var sql = "SELECT Id, Title, Author, ISBN, Genre, TotalCopies, AvailableCopies FROM Books";
            if (!string.IsNullOrWhiteSpace(searchTerm))
                sql += " WHERE Title LIKE @term OR Author LIKE @term OR ISBN LIKE @term";
            sql += " ORDER BY Title";

            using var command = new SqliteCommand(sql, connection);
            if (!string.IsNullOrWhiteSpace(searchTerm))
                command.Parameters.AddWithValue("@term", $"%{searchTerm}%");

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                books.Add(new Book
                {
                    Id = reader.GetInt32(0),
                    Title = reader.GetString(1),
                    Author = reader.GetString(2),
                    ISBN = reader.GetString(3),
                    Genre = reader.IsDBNull(4) ? "" : reader.GetString(4),
                    TotalCopies = reader.GetInt32(5),
                    AvailableCopies = reader.GetInt32(6)
                });
            }
            return books;
        }

        public static void AddBook(Book book)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = @"INSERT INTO Books (Title, Author, ISBN, Genre, TotalCopies, AvailableCopies)
                        VALUES (@title, @author, @isbn, @genre, @total, @available)";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@title", book.Title);
            command.Parameters.AddWithValue("@author", book.Author);
            command.Parameters.AddWithValue("@isbn", book.ISBN);
            command.Parameters.AddWithValue("@genre", book.Genre ?? "");
            command.Parameters.AddWithValue("@total", book.TotalCopies);
            command.Parameters.AddWithValue("@available", book.AvailableCopies);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        public static void UpdateBook(Book book)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = @"UPDATE Books SET Title=@title, Author=@author, ISBN=@isbn, Genre=@genre,
                        TotalCopies=@total, AvailableCopies=@available WHERE Id=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@title", book.Title);
            command.Parameters.AddWithValue("@author", book.Author);
            command.Parameters.AddWithValue("@isbn", book.ISBN);
            command.Parameters.AddWithValue("@genre", book.Genre ?? "");
            command.Parameters.AddWithValue("@total", book.TotalCopies);
            command.Parameters.AddWithValue("@available", book.AvailableCopies);
            command.Parameters.AddWithValue("@id", book.Id);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        public static bool BookHasAnyLoans(int bookId)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "SELECT COUNT(*) FROM Loans WHERE BookId=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@id", bookId);
            var count = (long)command.ExecuteScalar()!;
            return count > 0;
        }

        public static void DeleteBook(int bookId)
        {
            if (BookHasAnyLoans(bookId))
                throw new InvalidOperationException(
                    "This book can't be deleted because it has loan history (active or returned). " +
                    "Delete its loan records in the Loans tab first if you really need to remove it.");

            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "DELETE FROM Books WHERE Id=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@id", bookId);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        // -------------------------------------------------------------- Members

        public static List<Member> GetAllMembers(string? searchTerm = null)
        {
            var members = new List<Member>();
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var sql = "SELECT Id, FullName, Email, Phone, JoinDate FROM Members";
            if (!string.IsNullOrWhiteSpace(searchTerm))
                sql += " WHERE FullName LIKE @term OR Email LIKE @term";
            sql += " ORDER BY FullName";

            using var command = new SqliteCommand(sql, connection);
            if (!string.IsNullOrWhiteSpace(searchTerm))
                command.Parameters.AddWithValue("@term", $"%{searchTerm}%");

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                members.Add(new Member
                {
                    Id = reader.GetInt32(0),
                    FullName = reader.GetString(1),
                    Email = reader.GetString(2),
                    Phone = reader.IsDBNull(3) ? "" : reader.GetString(3),
                    JoinDate = DateTime.Parse(reader.GetString(4))
                });
            }
            return members;
        }

        public static void AddMember(Member member)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = @"INSERT INTO Members (FullName, Email, Phone, JoinDate)
                        VALUES (@name, @email, @phone, @joinDate)";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@name", member.FullName);
            command.Parameters.AddWithValue("@email", member.Email);
            command.Parameters.AddWithValue("@phone", member.Phone ?? "");
            command.Parameters.AddWithValue("@joinDate", member.JoinDate.ToString("yyyy-MM-dd"));
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        public static void UpdateMember(Member member)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "UPDATE Members SET FullName=@name, Email=@email, Phone=@phone WHERE Id=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@name", member.FullName);
            command.Parameters.AddWithValue("@email", member.Email);
            command.Parameters.AddWithValue("@phone", member.Phone ?? "");
            command.Parameters.AddWithValue("@id", member.Id);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        public static bool MemberHasAnyLoans(int memberId)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "SELECT COUNT(*) FROM Loans WHERE MemberId=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@id", memberId);
            var count = (long)command.ExecuteScalar()!;
            return count > 0;
        }

        public static void DeleteMember(int memberId)
        {
            if (MemberHasAnyLoans(memberId))
                throw new InvalidOperationException(
                    "This member can't be deleted because they have loan history (active or returned). " +
                    "Delete their loan records in the Loans tab first if you really need to remove them.");

            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "DELETE FROM Members WHERE Id=@id";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@id", memberId);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        // ---------------------------------------------------------------- Loans

        public static List<Loan> GetAllLoans(bool activeOnly = false)
        {
            var loans = new List<Loan>();
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var sql = @"SELECT L.Id, L.BookId, B.Title, L.MemberId, M.FullName,
                               L.LoanDate, L.DueDate, L.ReturnDate, L.IsReturned
                        FROM Loans L
                        JOIN Books B ON L.BookId = B.Id
                        JOIN Members M ON L.MemberId = M.Id";
            if (activeOnly)
                sql += " WHERE L.IsReturned = 0";
            sql += " ORDER BY L.DueDate";

            using var command = new SqliteCommand(sql, connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                loans.Add(new Loan
                {
                    Id = reader.GetInt32(0),
                    BookId = reader.GetInt32(1),
                    BookTitle = reader.GetString(2),
                    MemberId = reader.GetInt32(3),
                    MemberName = reader.GetString(4),
                    LoanDate = DateTime.Parse(reader.GetString(5)),
                    DueDate = DateTime.Parse(reader.GetString(6)),
                    ReturnDate = reader.IsDBNull(7) ? null : DateTime.Parse(reader.GetString(7)),
                    IsReturned = reader.GetInt32(8) == 1
                });
            }
            return loans;
        }

        public static void CheckoutBook(int bookId, int memberId, int loanDays = 14)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var checkSql = "SELECT AvailableCopies FROM Books WHERE Id=@id";
                using var checkCommand = new SqliteCommand(checkSql, connection, transaction);
                checkCommand.Parameters.AddWithValue("@id", bookId);
                var result = checkCommand.ExecuteScalar();

                if (result == null)
                    throw new InvalidOperationException("That book no longer exists.");

                var available = (long)result;
                if (available <= 0)
                    throw new InvalidOperationException("There are no available copies of this book to loan out.");

                var loanDate = DateTime.Now;
                var dueDate = loanDate.AddDays(loanDays);

                var insertSql = @"INSERT INTO Loans (BookId, MemberId, LoanDate, DueDate, IsReturned)
                                   VALUES (@bookId, @memberId, @loanDate, @dueDate, 0)";
                using var insertCommand = new SqliteCommand(insertSql, connection, transaction);
                insertCommand.Parameters.AddWithValue("@bookId", bookId);
                insertCommand.Parameters.AddWithValue("@memberId", memberId);
                insertCommand.Parameters.AddWithValue("@loanDate", loanDate.ToString("yyyy-MM-dd"));
                insertCommand.Parameters.AddWithValue("@dueDate", dueDate.ToString("yyyy-MM-dd"));
                insertCommand.ExecuteNonQuery();

                var updateSql = "UPDATE Books SET AvailableCopies = AvailableCopies - 1 WHERE Id=@id";
                using var updateCommand = new SqliteCommand(updateSql, connection, transaction);
                updateCommand.Parameters.AddWithValue("@id", bookId);
                updateCommand.ExecuteNonQuery();

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

            AppEvents.RaiseDataChanged();
        }

        public static void ReturnBook(int loanId)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                int bookId;
                bool alreadyReturned;

                var getSql = "SELECT BookId, IsReturned FROM Loans WHERE Id=@id";
                using (var getCommand = new SqliteCommand(getSql, connection, transaction))
                {
                    getCommand.Parameters.AddWithValue("@id", loanId);
                    using var reader = getCommand.ExecuteReader();
                    if (!reader.Read())
                        throw new InvalidOperationException("That loan record no longer exists.");

                    bookId = reader.GetInt32(0);
                    alreadyReturned = reader.GetInt32(1) == 1;
                }

                if (alreadyReturned)
                    throw new InvalidOperationException("This loan has already been marked as returned.");

                var updateLoanSql = "UPDATE Loans SET IsReturned=1, ReturnDate=@returnDate WHERE Id=@id";
                using (var updateLoanCommand = new SqliteCommand(updateLoanSql, connection, transaction))
                {
                    updateLoanCommand.Parameters.AddWithValue("@returnDate", DateTime.Now.ToString("yyyy-MM-dd"));
                    updateLoanCommand.Parameters.AddWithValue("@id", loanId);
                    updateLoanCommand.ExecuteNonQuery();
                }

                var updateBookSql = "UPDATE Books SET AvailableCopies = AvailableCopies + 1 WHERE Id=@id";
                using (var updateBookCommand = new SqliteCommand(updateBookSql, connection, transaction))
                {
                    updateBookCommand.Parameters.AddWithValue("@id", bookId);
                    updateBookCommand.ExecuteNonQuery();
                }

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

            AppEvents.RaiseDataChanged();
        }

        /// <summary>
        /// Deletes a loan record entirely. If the loan was still active (not yet
        /// returned), the book's available copy count is restored first - otherwise
        /// that copy would be lost from the pool forever. If it was already
        /// returned, the copy count was already restored at return time, so it's
        /// left untouched here.
        /// </summary>
        public static void DeleteLoan(int loanId)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                int bookId;
                bool wasReturned;

                var getSql = "SELECT BookId, IsReturned FROM Loans WHERE Id=@id";
                using (var getCommand = new SqliteCommand(getSql, connection, transaction))
                {
                    getCommand.Parameters.AddWithValue("@id", loanId);
                    using var reader = getCommand.ExecuteReader();
                    if (!reader.Read())
                        throw new InvalidOperationException("That loan record no longer exists.");

                    bookId = reader.GetInt32(0);
                    wasReturned = reader.GetInt32(1) == 1;
                }

                var deleteSql = "DELETE FROM Loans WHERE Id=@id";
                using (var deleteCommand = new SqliteCommand(deleteSql, connection, transaction))
                {
                    deleteCommand.Parameters.AddWithValue("@id", loanId);
                    deleteCommand.ExecuteNonQuery();
                }

                if (!wasReturned)
                {
                    var updateSql = "UPDATE Books SET AvailableCopies = AvailableCopies + 1 WHERE Id=@id";
                    using var updateCommand = new SqliteCommand(updateSql, connection, transaction);
                    updateCommand.Parameters.AddWithValue("@id", bookId);
                    updateCommand.ExecuteNonQuery();
                }

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

            AppEvents.RaiseDataChanged();
        }

        // ---------------------------------------------------- Transaction History

        public static void LogTransaction(string staffName, string actionType, string details)
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = @"INSERT INTO TransactionHistory (Timestamp, StaffName, ActionType, Details)
                        VALUES (@timestamp, @staffName, @actionType, @details)";
            using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            command.Parameters.AddWithValue("@staffName", staffName);
            command.Parameters.AddWithValue("@actionType", actionType);
            command.Parameters.AddWithValue("@details", details);
            command.ExecuteNonQuery();
            AppEvents.RaiseDataChanged();
        }

        public static List<TransactionLogEntry> GetAllTransactions()
        {
            var entries = new List<TransactionLogEntry>();
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();
            var sql = "SELECT Id, Timestamp, StaffName, ActionType, Details FROM TransactionHistory ORDER BY Timestamp DESC";
            using var command = new SqliteCommand(sql, connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                entries.Add(new TransactionLogEntry
                {
                    Id = reader.GetInt32(0),
                    Timestamp = DateTime.Parse(reader.GetString(1)),
                    StaffName = reader.GetString(2),
                    ActionType = reader.GetString(3),
                    Details = reader.GetString(4)
                });
            }
            return entries;
        }
    }
}
