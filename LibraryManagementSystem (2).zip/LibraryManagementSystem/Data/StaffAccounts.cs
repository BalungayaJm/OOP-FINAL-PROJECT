using System;
using System.Collections.Generic;

namespace LibraryManagementSystem.Data
{
    public readonly struct StaffAccount
    {
        public string Name { get; init; }
        public string Email { get; init; }
        public string Password { get; init; }
    }

    /// <summary>
    /// Prototype-only accounts. In a real system these would live in the database
    /// with hashed passwords, not hardcoded in source code.
    /// </summary>
    public static class StaffAccounts
    {
        private static readonly List<StaffAccount> Accounts = new()
        {
            new StaffAccount { Name = "Juan Dela Cruz", Email = "jdelacruz@library.com", Password = "Staff123" },
            new StaffAccount { Name = "Maria Santos",   Email = "msantos@library.com",   Password = "Staff123" },
            new StaffAccount { Name = "Admin Account",  Email = "admin@library.com",     Password = "Admin123" },
        };

        public static StaffAccount? Validate(string email, string password)
        {
            foreach (var account in Accounts)
            {
                if (string.Equals(account.Email, email, StringComparison.OrdinalIgnoreCase)
                    && account.Password == password)
                {
                    return account;
                }
            }
            return null;
        }
    }
}
