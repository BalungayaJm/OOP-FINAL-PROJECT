namespace LibraryManagementSystem.Data
{
    public static class Session
    {
        public static string StaffName { get; set; } = "Unknown Staff";
        public static string StaffEmail { get; set; } = "";
    }
}
