using System;

namespace LibraryManagementSystem.Data
{
    /// <summary>
    /// Fired after any add/update/delete/checkout/return so every open tab can
    /// refresh itself, even if the change happened from a different tab.
    /// </summary>
    public static class AppEvents
    {
        public static event Action? DataChanged;

        public static void RaiseDataChanged() => DataChanged?.Invoke();
    }
}
