using System.Windows;
using LibraryManagementSystem.Data;

namespace LibraryManagementSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoggedInLabel.Text = $"Logged in as: {Session.StaffName}";
        }
    }
}
