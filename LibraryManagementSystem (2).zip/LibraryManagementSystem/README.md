# Library Management System

A C# WPF desktop app with a SQLite backend for managing books, members, and loans,
with staff login and a full transaction history log.

## Login (prototype accounts)

The app opens to a login screen first. These three accounts are hardcoded for
demo purposes (in a real system these would be stored securely in the database):

| Name            | Email                    | Password  |
|------------------|--------------------------|-----------|
| Juan Dela Cruz   | jdelacruz@library.com    | Staff123  |
| Maria Santos     | msantos@library.com      | Staff123  |
| Admin Account    | admin@library.com        | Admin123  |

Any other email/password combination shows an error and won't log in.

## How it maps to the rubric

| Requirement | How it's met |
|---|---|
| Programming Language: C# | Entire app is C# / WPF / XAML |
| Project Type | Desktop Application (WPF) |
| Database/Backend | SQLite database (`library.db`), created automatically on first run, with full CRUD and a transaction-history table |
| Functionality | Login, add/edit/delete books, members and loans, checkout/return workflow, search on every tab, credential-confirmed deletes, input validation, try/catch error handling throughout |
| User Interface | Tabbed layout (Books / Members / Loans / History), consistent styling, colored status badges, inline error messages |
| Project Demonstration | See the demo script below |

## Setup (Visual Studio 2022+, Windows)

1. Install the **.NET desktop development** workload in Visual Studio if you don't have it.
2. Open `LibraryManagementSystem.csproj`.
3. Let NuGet restore `Microsoft.Data.Sqlite` (automatic on build, or right-click the project → Manage NuGet Packages / Restore).
4. Press F5 to run. The login window appears first; `library.db` is created next to the .exe on first run.

## Demo script (~6 minutes)

1. **Login** — show a wrong password being rejected, then log in with one of the accounts above.
2. **Books tab** — add a book (show ISBN validation failing, then fix it). Edit a book's copy count. Try deleting a book that has any loan history to show the guard rail. Point out the Available column turning red at 0.
3. **Members tab** — add a member (show the email validation catching a bad address). Edit a phone number.
4. **Loans tab** — check out a book, switch to Books to show the Available count actually drops now. Double-click the loan in Active Loans, confirm "Yes," show it move to Returned. Try the search box. Try "Delete Selected" on a loan — show the credential prompt, cancel it once, then confirm it with valid credentials.
5. **History tab** — show every action just performed (login-independent staff name, action type, details, timestamp) logged automatically. Search it by staff name or action.
6. Mention the database persists across restarts (`library.db`, local file, no server needed).

## Project structure

```
LibraryManagementSystem/
├── App.xaml / App.xaml.cs          # Shared styling; startup flow: DB init -> Login -> MainWindow
├── LoginWindow.xaml(.cs)           # Staff login screen
├── ConfirmCredentialsWindow.xaml(.cs)  # Re-confirmation dialog required before every delete
├── MainWindow.xaml / .cs           # Shell window with the 4 tabs
├── Models/                         # Book, Member, Loan, TransactionLogEntry
├── Data/
│   ├── DatabaseHelper.cs           # All SQLite access (CRUD, checkout/return, history log)
│   ├── AppEvents.cs                # App-wide "data changed" signal so every tab stays in sync
│   ├── Session.cs                  # Currently logged-in staff member
│   └── StaffAccounts.cs            # Hardcoded prototype accounts
└── Views/                          # BooksView, MembersView, LoansView, HistoryView
```
